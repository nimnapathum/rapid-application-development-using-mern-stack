function find_color(fruit) {
    switch (fruit) {
        case "banana":
            alert("Yellow");
            break;
        case "pineapple":
            alert("Orange");
            break;
        case "apple":
            alert("Green");
            break;
        default:
            break;
    }
}
find_color("banana");