function findRoot(num = prompt("Enter a number")) {
    return Math.pow(num, 2);
}

findRoot();